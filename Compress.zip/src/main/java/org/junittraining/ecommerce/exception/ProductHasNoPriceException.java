package org.junittraining.ecommerce.exception;

public class ProductHasNoPriceException extends RuntimeException {
    
}
